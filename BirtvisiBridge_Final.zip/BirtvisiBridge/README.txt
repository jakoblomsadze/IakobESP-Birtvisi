Birtvisi Bridge Android Project - Defaults included
Token=SECRET123
Device=esp1
ESP Base URL=http://192.168.86.18
Interval=2s
